@extends('layouts.main')

@section('title', 'METAR TAF SPECI - Sentani')

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="#" class="text-decoration-none">Penerbangan</a></li>
    <li class="breadcrumb-item" aria-current="page">Metar & TAF</li>
@endsection

@section('page_title', 'Metar Taf Speci Sentani')

@section('page_description')
    Informasi Metar, TAF, dan Speci.
@endsection

@section('content')
<script src="https://cdn.tailwindcss.com"></script>

<div class="font-sans text-slate-800 antialiased my-4">
    <div class="bg-gradient-to-r from-blue-800 to-indigo-900 text-white p-6 rounded-t-xl shadow-md flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div class="flex items-center gap-4">
            <div class="bg-white/10 p-3 rounded-lg border border-white/20">
                <i class="fa-solid fa-plane-departure text-3xl text-amber-400"></i>
            </div>
            <div>
                <h2 class="text-xl md:text-2xl font-black tracking-wide uppercase">Bandara Internasional Sentani</h2>
                <p class="text-xs md:text-sm font-mono text-indigo-200 mt-0.5">Stasiun Meteorologi Kelas I Sentani — Indeks ICAO: <span class="bg-amber-400 text-slate-900 font-bold px-1.5 py-0.5 rounded text-xs ml-1">{{ $icao }}</span></p>
            </div>
        </div>
        <div class="text-left md:text-right bg-black/20 px-4 py-2 rounded-lg border border-white/10 w-full md:w-auto">
            <span class="text-[10px] uppercase font-bold text-slate-300 block tracking-wider">Pembaruan Sistem Realtime</span>
            <span class="text-xs md:text-sm font-mono text-amber-300 font-bold"><i class="fa-solid fa-clock-rotate-left mr-1"></i> {{ $waktu_update }}</span>
        </div>
    </div>

    <div class="bg-white rounded-b-xl border-x border-b border-slate-200 p-6 shadow-xl grid grid-cols-1 gap-6">
        
        <div class="bg-slate-50 border border-slate-200 rounded-xl p-5 shadow-sm transition hover:shadow-md">
            <div class="flex items-center gap-2 border-b border-slate-200 pb-3 mb-4">
                <span class="bg-blue-600 text-white font-black text-xs px-2.5 py-1 rounded shadow-sm">METAR</span>
                <h4 class="text-sm font-bold text-slate-500 uppercase tracking-wider">Meteorological Aerodrome Report</h4>
            </div>
            <div class="bg-slate-900 text-emerald-400 font-mono text-base md:text-lg p-4 rounded-lg border border-slate-950 shadow-inner select-all leading-relaxed break-words">
                {{ $metar }}
            </div>
            <p class="text-[11px] text-slate-400 mt-2 italic"><i class="fa-solid fa-info-circle mr-1 text-slate-400"></i> Data sandi cuaca aktual bandara penerbangan rutin yang dilaporkan setiap setengah atau satu jam sekali.</p>
        </div>

        <div class="bg-slate-50 border border-slate-200 rounded-xl p-5 shadow-sm transition hover:shadow-md">
            <div class="flex items-center gap-2 border-b border-slate-200 pb-3 mb-4">
                <span class="bg-emerald-600 text-white font-black text-xs px-2.5 py-1 rounded shadow-sm">TAF</span>
                <h4 class="text-sm font-bold text-slate-500 uppercase tracking-wider">Terminal Aerodrome Forecast</h4>
            </div>
            <div class="bg-slate-900 text-amber-400 font-mono text-base md:text-lg p-4 rounded-lg border border-slate-950 shadow-inner select-all leading-relaxed break-words">
                {{ $taf }}
            </div>
            <p class="text-[11px] text-slate-400 mt-2 italic"><i class="fa-solid fa-info-circle mr-1 text-slate-400"></i> Data ramalan cuaca kawasan bandar udara untuk periode validitas tertentu (biasanya 24 - 30 jam kedepan).</p>
        </div>

        <div class="bg-slate-50 border border-slate-200 rounded-xl p-5 shadow-sm transition hover:shadow-md">
            <div class="flex items-center gap-2 border-b border-slate-200 pb-3 mb-4">
                <span class="bg-red-600 text-white font-black text-xs px-2.5 py-1 rounded shadow-sm">SPECI</span>
                <h4 class="text-sm font-bold text-slate-500 uppercase tracking-wider">Aviation Special Weather Report</h4>
            </div>
            <div class="bg-slate-900 text-rose-400 font-mono text-base md:text-lg p-4 rounded-lg border border-slate-950 shadow-inner select-all leading-relaxed break-words">
                {{ $speci }}
            </div>
            <p class="text-[11px] text-slate-400 mt-2 italic"><i class="fa-solid fa-info-circle mr-1 text-slate-400"></i> Laporan khusus yang diterbitkan seketika di luar jadwal rutin apabila terjadi perubahan cuaca signifikan (ekstrem).</p>
        </div>

    </div>
</div>
@endsection