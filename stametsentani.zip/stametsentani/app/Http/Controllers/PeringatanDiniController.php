<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

class PeringatanDiniController extends Controller
{
    public function index()
    {
        $rss_url = "https://www.bmkg.go.id/alerts/nowcast/id/rss.xml?v=" . time(); 
        $alerts = [];

        // Ditambah kata kunci provinsi baru di Papua agar lebih aman
        $wilayahPapua = [
            'Papua', 'Jayapura', 'Sentani', 'Keerom', 'Sarmi', 'Biak', 'Serui', 
            'Nabire', 'Mimika', 'Merauke', 'Wamena', 'Mappi', 'Asmat', 'Boven Digoel',
            'Pegunungan', 'Intan Jaya', 'Paniai', 'Puncak', 'Dogiyai', 'Deiyai', 'Sorong', 'Manokwari'
        ];

        try {
            $response = Http::withoutVerifying()->timeout(10)->get($rss_url);
    
            if ($response->successful()) {
                $xml = simplexml_load_string($response->body());
            
                if (isset($xml->channel->item)) {
                    foreach ($xml->channel->item as $item) {
                        $title = (string)$item->title;
                        $description = (string)$item->description;
                    
                        // Gabungkan judul dan deskripsi agar pencarian wilayah lebih akurat
                        $fullContent = $title . ' ' . $description;
                    
                        $isPapua = false;
                        foreach ($wilayahPapua as $wilayah) {
                            if (stripos($fullContent, $wilayah) !== false) {
                                $isPapua = true;
                                break;
                            }
                        }

                        // Pengecualian hanya untuk Pulau Lain, hindari kata arah mata angin (Barat/Timur)
                        if ($isPapua) {
                            $pulauLain = ['Sumatera', 'Jawa', 'Sulawesi', 'Kalimantan', 'Bali', 'Nusa Tenggara', 'Maluku'];
                            foreach ($pulauLain as $pulau) {
                                // Jika ada nama pulau lain DAN tidak ada kata Papua sama sekali, batalkan.
                                if (stripos($fullContent, $pulau) !== false && stripos($fullContent, 'Papua') === false) {
                                    $isPapua = false;
                                    break;
                                }
                            }
                        }

                        if ($isPapua) {
                            $alerts[] = [
                                'title'       => trim($title),
                                'link'        => trim((string)$item->link),
                                'description' => trim(strip_tags($description)),
                                'pubDate'     => trim((string)$item->pubDate),
                                'author'      => trim((string)$item->author),
                            ];
                        }
                    }
                }
            }
        } catch (\Exception $e) {
            $alerts = [];
        }

        return view('peringatandini', compact('alerts'));
    }

    public function getCapDetail(Request $request)
    {
        $url = $request->query('url');
        if (!$url) return response()->json(['error' => 'URL required'], 400);

        try {
            // Gunakan Http client agar konsisten dengan bypass SSL
            $response = Http::withoutVerifying()->get($url);
            $xml = simplexml_load_string($response->body());
            
            $namespaces = $xml->getNamespaces(true);
            $cap_ns = $namespaces[""] ?? "urn:oasis:names:tc:emergency:cap:1.2";
            $info = $xml->children($cap_ns)->info;

            // Mengambil URL gambar infografis dari elemen <web> di XML BMKG
            $imageUrl = isset($info->web) ? (string)$info->web : null;

            $polygons = [];
            if ($info && isset($info->area)) {
                foreach ($info->area as $area) {
                    if (isset($area->polygon)) {
                        foreach ($area->polygon as $poly_str) {
                            $coords = [];
                            $pairs = explode(" ", trim((string)$poly_str));
                            foreach ($pairs as $pair) {
                                $lat_lon = explode(",", $pair);
                                if (count($lat_lon) === 2) {
                                    $coords[] = [(float)$lat_lon[0], (float)$lat_lon[1]];
                                }
                            }
                            $polygons[] = $coords;
                        }
                    }
                }
            }

            return response()->json([
                'polygons' => $polygons,
                'image_url' => $imageUrl,
                'headline' => (string)($info->headline ?? 'Peringatan Dini'),
                'area'     => (string)($info->area->areaDesc ?? 'Wilayah Papua'),
                'description' => (string)($info->description ?? ''),
                'instruction' => (string)($info->instruction ?? 'Tetap waspada.')
            ]);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Data tidak ditemukan'], 404);
        }
    }
}