

<?php $__env->startSection('title', 'Admin - Kelola Flight Document'); ?>
<?php $__env->startSection('page_title', 'Manajemen Dokumen Penerbangan'); ?>
<?php $__env->startSection('page_description', 'Halaman khusus Admin Meteorologi untuk mengunggah dokumen penerbangan / MET-Folder maskapai.'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="#">Admin</a></li>
    <li class="breadcrumb-item active" aria-current="page">Flight Document</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-4">
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-1"></i> <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <div class="col-lg-4">
            <div class="card shadow-sm border border-primary-subtle rounded-4">
                <div class="card-header bg-primary text-white fw-bold py-3 rounded-top-4">
                    <i class="bi bi-upload me-1"></i> Form Upload Dokumen
                </div>
                <div class="card-body p-4">
                    <form action="<?php echo e(route('admin.flightdoc.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Target Maskapai</label>
                            <select name="airline" class="form-select" required>
                                <option value="" selected disabled>-- Pilih Maskapai --</option>
                                <?php $__currentLoopData = $airlines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $airline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($airline); ?>"><?php echo e($airline); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Nomor Penerbangan</label>
                            <input type="text" name="flight_number" class="form-control" placeholder="Contoh: GA-650 / LNI-782" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Nama/Keterangan Dokumen</label>
                            <input type="text" name="document_name" class="form-control" placeholder="Contoh: Flight Doc 07 Juni 2026 Pagi" required>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-bold">Berkas File Document</label>
                            <input type="file" name="file_flight" class="form-control" required>
                            <div class="form-text text-danger">Format: pdf, zip, rar, doc. Maksimal 20MB.</div>
                        </div>

                        <button type="submit" class="btn btn-primary w-100 fw-bold py-2 shadow">
                            <i class="bi bi-cloud-plus-fill me-1"></i> Upload Sekarang
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-8">
            <div class="card shadow-sm border rounded-4">
                <div class="card-header bg-dark text-white py-2.5 rounded-top-4 d-flex justify-content-between align-items-center">
                    <span class="fw-bold">
                        <i class="bi bi-collection-play me-1"></i> List Dokumen Aktif
                    </span>
                    <a href="<?php echo e(route('admin.flightdoc.logs')); ?>" class="btn btn-primary fw-bold btn-sm rounded-3 shadow-sm px-3">
                        <i class="bi bi-clock-history me-1"></i> Lihat Log Riwayat Unduhan
                    </a>
                </div>
                
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead>
                                <tr class="table-light">
                                    <th class="ps-3">Maskapai</th>
                                    <th>Flight No</th>
                                    <th>Keterangan</th>
                                    <th>Dibuat</th>
                                    <th class="text-center pe-3">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="ps-3"><strong class="text-primary"><?php echo e($doc->airline); ?></strong></td>
                                        <td><span class="badge bg-secondary font-monospace"><?php echo e($doc->flight_number); ?></span></td>
                                        <td><small class="fw-bold text-dark"><?php echo e($doc->document_name); ?></small></td>
                                        <td><small class="text-muted"><?php echo e($doc->created_at->format('d/m/Y H:i')); ?></small></td>
                                        <td class="text-center pe-3">
                                            <div class="d-flex justify-content-center gap-1">
                                                <a href="<?php echo e(route('flightdoc.download', $doc->id)); ?>" class="btn btn-light btn-sm text-success" title="Download File" onclick="event.preventDefault(); document.getElementById('admin-download-form-<?php echo e($doc->id); ?>').submit();">
                                                    <i class="bi bi-download"></i>
                                                </a>
                                                <form id="admin-download-form-<?php echo e($doc->id); ?>" action="<?php echo e(route('flightdoc.download', $doc->id)); ?>" method="POST" style="display: none;">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="downloader_name" value="Admin Meteorologi">
                                                    <input type="hidden" name="downloader_position" value="Administrator / Petugas Stamet">
                                                </form>

                                                <form action="<?php echo e(route('admin.flightdoc.destroy', $doc->id)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus dokumen ini?')">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-light btn-sm text-danger" title="Hapus">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="text-center py-5 text-muted">Belum ada file flight document yang tersimpan.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/stametsentani/resources/views/admin/flightdoc/index.blade.php ENDPATH**/ ?>