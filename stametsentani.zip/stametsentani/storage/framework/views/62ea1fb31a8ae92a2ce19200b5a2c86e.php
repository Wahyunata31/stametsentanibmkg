

<?php $__env->startSection('title', 'Gempa Bumi Dirasakan'); ?>

<?php $__env->startSection('page_title', 'Gempa Bumi Dirasakan'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="#" class="text-decoration-none">Gempa Bumi</a></li>
    <li class="breadcrumb-item" aria-current="page">Gempa Bumi Dirasakan</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title', 'Gempa Bumi Dirasakan'); ?>

<?php $__env->startSection('page_description'); ?>
    Informasi gempa bumi dirasakan di wilayah Indonesia.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2 class="mb-4">Daftar 15 Gempabumi Dirasakan</h2>
    <div class="table-responsive shadow-sm border rounded">
        <table class="table table-hover mb-0">
            <thead class="table-info text-dark">
                <tr>
                    <th>No</th><th>Waktu</th><th>Magnitudo</th><th>Kedalaman</th><th>Wilayah</th><th>Dirasakan (Skala MMI)</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data->gempa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $gd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($gd->Tanggal); ?> <?php echo e($gd->Jam); ?></td> 
                    <td><?php echo e($gd->Magnitude); ?> SR</td> 
                    <td><?php echo e($gd->Kedalaman); ?></td> 
                    <td><?php echo e($gd->Wilayah); ?></td>
                    <td><span class="text-primary"><?php echo e($gd->Dirasakan); ?></span></td> 
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <p class="mt-3 text-muted small">* Sumber: BMKG</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/stametsentani/resources/views/gempa/dirasakan.blade.php ENDPATH**/ ?>