

<?php $__env->startSection('title', 'SDM'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="#" class="text-decoration-none">Profil</a></li>
    <li class="breadcrumb-item " aria-current="page">SDM</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title', 'SDM'); ?>

<?php $__env->startSection('page_description'); ?>
    Profil Sumber Daya Manusia dan Aparatur Sipil Negara di lingkungan Stasiun Meteorologi Kelas I Sentani.

<?php $__env->startSection('content'); ?>
<div class="card border-0 shadow-sm p-4 mb-4">
    <h2 class="h4 border-bottom pb-2 mb-3">Sumber Daya Manusia (SDM)</h2>
    <p>Stasiun Meteorologi Kelas I Sentani didukung oleh tenaga profesional yang kompeten di bidang Meteorologi, Klimatologi, dan Geofisika, yang terdiri dari:</p>
    <ul>
        <li>Pegawai Aparatur Sipil Negara (ASN) Struktural dan Fungsional.</li>
        <li>Observer / Pengamat Cuaca Udara Atas dan Permukaan.</li>
        <li>Teknisi Peralatan Meteorologi (Aloptama).</li>
        <li>Prakirawan Cuaca (Forecaster) Penerbangan dan Publik.</li>
    </ul>
    
    <p class="mt-3">Sesuai dengan Misi BMKG, kami terus mendorong peningkatan kapasitas SDM melalui pelatihan berkelanjutan guna mewujudkan personel yang berdaya saing global serta adaptif terhadap kemajuan teknologi radar dan otomasi cuaca modern.</p>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/stametsentani/resources/views/sdm.blade.php ENDPATH**/ ?>