
<?php $__env->startSection('title', 'Gempa Bumi Terbaru'); ?>

<?php $__env->startSection('page_title', 'Gempa Bumi Terbaru'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="#" class="text-decoration-none">Gempa Bumi</a></li>
    <li class="breadcrumb-item" aria-current="page">Gempa Bumi Terbaru</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title', 'Gempa Bumi Terbaru'); ?>

<?php $__env->startSection('page_description'); ?>
    Informasi gempa bumi terbaru di wilayah Indonesia.
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2 class="mb-4">Gempabumi Terbaru</h2>
    <div class="card shadow-sm">
        <div class="row g-0">
            <div class="col-md-5 text-center p-3">
                <img src="https://data.bmkg.go.id/DataMKG/TEWS/<?php echo e($data->gempa->Shakemap); ?>" class="img-fluid rounded" alt="Shakemap"> 
            </div>
            <div class="col-md-7">
                <div class="card-body">
                    <table class="table">
                        <tr><th>Tanggal / Jam</th><td><?php echo e($data->gempa->Tanggal); ?> / <?php echo e($data->gempa->Jam); ?></td></tr>
                        <tr><th>Magnitudo</th><td><span class="badge bg-danger"><?php echo e($data->gempa->Magnitude); ?> SR</span></td></tr>
                        <tr><th>Kedalaman</th><td><?php echo e($data->gempa->Kedalaman); ?></td></tr> 
                        <tr><th>Lokasi</th><td><?php echo e($data->gempa->Wilayah); ?></td></tr> 
                        <tr><th>Potensi</th><td><strong><?php echo e($data->gempa->Potensi); ?></strong></td></tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <p class="mt-3 text-muted small">* Sumber: BMKG</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/stametsentani/resources/views/gempa/terbaru.blade.php ENDPATH**/ ?>