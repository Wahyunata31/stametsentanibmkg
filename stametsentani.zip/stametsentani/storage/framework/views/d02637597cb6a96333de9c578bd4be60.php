

<?php $__env->startSection('title', 'Login Maskapai - Flight Document'); ?>
<?php $__env->startSection('page_title', 'Flight Document Login'); ?>
<?php $__env->startSection('page_description', 'Silakan pilih maskapai Anda dan masukkan password resmi untuk mengakses lembar dokumen penerbangan.'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="#">Penerbangan</a></li>
    <li class="breadcrumb-item active" aria-current="page">Flight Document</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center my-4">
    <div class="col-md-5">
        <div class="card shadow border-0" style="border-radius: 15px;">
            <div class="card-body p-4">
                <div class="text-center mb-4">
                    <i class="bi bi-airplane-fill text-primary" style="font-size: 3rem;"></i>
                    <h4 class="fw-bold mt-2">Flight Doc Station</h4>
                </div>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('flightdoc.login.submit')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="airline" class="form-label fw-bold">Pilih Maskapai</label>
                        <select name="airline" id="airline" class="form-select" required>
                            <option value="" selected disabled>-- Pilih Maskapai Anda --</option>
                            <?php $__currentLoopData = $airlines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $airline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($airline); ?>"><?php echo e($airline); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-4">
                        <label for="password" class="form-label fw-bold">Password Penerbangan</label>
                        <input type="password" name="password" id="password" class="form-control" placeholder="Masukkan password khusus" required>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 py-2 fw-bold shadow-sm rounded-3">
                        <i class="bi bi-box-arrow-in-right me-1"></i> Masuk Ruang Unduh
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/stametsentani/resources/views/flightdoc/login.blade.php ENDPATH**/ ?>