

<?php $__env->startSection('title', 'Citra Satelit Wilayah Papua'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="#" class="text-decoration-none">Prakiraan</a></li>
    <li class="breadcrumb-item" aria-current="page">Citra Satelit Wilayah Papua</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title', 'Citra Satelit'); ?>

<?php $__env->startSection('page_description'); ?>
    Citra Satelit Wilayah Papua.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h5 class="card-title mb-0">Citra Satelit Himawari-8 (Papua)</h5>
        </div>
        <div class="card-body text-center">
            
            
            <img src="<?php echo e(route('citra.stream', ['type' => 'satelit_eh'])); ?>&t=<?php echo e(time()); ?>"
                alt="Citra Satelit Papua EH" 
                class="img-fluid border shadow-sm" 
                style="max-width: 70%; height: auto;"
                onerror="this.onerror=null; this.src='https://via.placeholder.com/800x600?text=Server+Pusat+Offline';">

            <div class="mt-3">
                <p class="text-muted small">
                    <strong>Status:</strong> Terhubung.
                </p>
            </div>

            <div class="mt-4 text-start p-3 bg-light border rounded">
                <h6 class="fw-bold"><i class="bi bi-info-circle me-2"></i>Keterangan Warna (Suhu Puncak Awan):</h6>
                <ul class="small mb-0">
                    <li><strong>Putih/Abu-abu Terang:</strong> Suhu sangat dingin (< -60°C), mengindikasikan awan Cumulonimbus yang sangat tebal dan potensi hujan sangat lebat.</li>
                    <li><strong>Merah/Jingga:</strong> Suhu dingin (-50°C s/d -60°C), awan tebal dengan potensi hujan sedang hingga lebat.</li>
                    <li><strong>Kuning/Hijau:</strong> Suhu cukup dingin (-30°C s/d -50°C), terdapat awan dengan potensi hujan ringan.</li>
                    <li><strong>Biru/Hitam:</strong> Area cerah atau awan rendah yang tidak berpotensi hujan signifikan.</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/stametsentani/resources/views/citrasatelit.blade.php ENDPATH**/ ?>