

<?php $__env->startSection('title', 'Buletin Bulanan'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active" aria-current="page">Buletin</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title', 'Buletin Bulanan'); ?>

<?php $__env->startSection('page_description'); ?>
    Buletin Resmi Stasiun Meteorologi Kelas I Sentani Jayapura.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <?php if($bulletins->isEmpty()): ?>
        <div class="alert alert-info text-center">
            Belum ada buletin yang diterbitkan saat ini.
        </div>
    <?php else: ?>
        <div class="row">
            <?php $__currentLoopData = $bulletins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulletin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100 shadow-sm border-0 overflow-hidden">
                        
                        <div class="position-relative bg-light text-center" style="height: 250px; overflow: hidden;">
                            <?php if($bulletin->cover_image): ?>
                                <img src="<?php echo e(asset('bulletins/covers/' . $bulletin->cover_image)); ?>" 
                                     alt="Sampul <?php echo e($bulletin->title); ?>" 
                                     class="w-100 h-100" 
                                     style="object-fit: cover; object-position: top;">
                            <?php else: ?>
                                <div class="d-flex align-items-center justify-content-center h-100">
                                    <i class="bi bi-file-earmark-pdf-fill text-danger" style="font-size: 4rem;"></i>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="card-body p-3">
                            <h5 class="card-title fw-bold text-dark text-truncate mb-1" title="<?php echo e($bulletin->title); ?>">
                                <?php echo e($bulletin->title); ?>

                            </h5>
                            <p class="text-muted small mb-0">
                                <i class="bi bi-calendar3"></i> Terbit: <?php echo e(\Carbon\Carbon::parse($bulletin->publish_date)->translatedFormat('d F Y')); ?>

                            </p>
                        </div>
                        <div class="card-footer bg-transparent border-0 pb-3 pt-0">
                            <a href="<?php echo e(asset('bulletins/' . $bulletin->pdf_file)); ?>" target="_blank" class="btn btn-primary btn-sm w-100">
                                <i class="bi bi-eye"></i> Baca / Download PDF
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/stametsentani/resources/views/buletin.blade.php ENDPATH**/ ?>