

<?php $__env->startSection('title', 'Prakiraan Cuaca - Kabupaten Jayapura'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="#" class="text-decoration-none">Prakiraan</a></li>
    <li class="breadcrumb-item active" aria-current="page">Prakiraan Cuaca</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title', 'Prakiraan Cuaca'); ?>

<?php $__env->startSection('page_description'); ?>
    Prakiraan cuaca wilayah Kabupaten, Kota Jayapura, dan Sekitarnya.
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title', 'Prakiraan Cuaca - Papua'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card border-0 shadow-sm" style="border-radius: 15px;">
                <div class="card-body">
                    <form action="<?php echo e(url('/cuaca-prakiraan')); ?>" method="GET">
                        <label class="form-label fw-bold text-muted small uppercase">PILIH LOKASI WILAYAH</label>
                        <select name="kode_wilayah" class="form-select form-select-lg border-0 bg-light" onchange="this.form.submit()" style="border-radius: 10px;">
                            <?php $__currentLoopData = $wilayahList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kode => $nama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($kode); ?>" <?php echo e($selectedAdm == $kode ? 'selected' : ''); ?>><?php echo e($nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php if(isset($data['data'][0]['cuaca'])): ?>
        <?php $lokasi = $data['lokasi']; ?>
        
        <h4 class="fw-bold mb-3">Prakiraan Cuaca di <?php echo e($lokasi['desa']); ?>, <?php echo e($lokasi['kecamatan']); ?></h4>

        <div class="row">
            <?php $__currentLoopData = $data['data'][0]['cuaca']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indexHari => $hari): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <div class="col-12 mt-4 mb-2">
                    <h5 class="text-primary fw-bold">Hari ke-<?php echo e($indexHari + 1); ?></h5>
                </div>

                <?php $__currentLoopData = $hari; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="card border-0 shadow-sm h-100" style="border-radius: 20px; overflow: hidden;">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="badge bg-soft-primary text-primary px-3 py-2" style="background-color: #e7f1ff; border-radius: 10px;">
                                    <i class="far fa-clock me-1"></i> <?php echo e(\Carbon\Carbon::parse($jam['local_datetime'])->format('H:i')); ?> WIT
                                </span>
                                <span class="text-muted small"><?php echo e(\Carbon\Carbon::parse($jam['local_datetime'])->format('d M Y')); ?></span>
                            </div>

                            <div class="d-flex align-items-center">
                                
                                <div class="shrink-0 me-3">
                                    <img src="<?php echo e(str_replace(' ', '%20', $jam['image'])); ?>" alt="icon" style="width: 70px; height: 70px; object-fit: contain;">
                                </div>
                                
                                
                                <div>
                                    <h2 class="mb-0 fw-bold"><?php echo e($jam['t']); ?>°C</h2>
                                    <p class="text-muted mb-0 fw-semibold"><?php echo e($jam['weather_desc']); ?></p>
                                </div>
                            </div>

                            <hr class="my-3 opacity-25">

                            
                            <div class="row text-center">
                                <div class="col-4">
                                    <p class="text-muted small mb-1">Lembap</p>
                                    <p class="fw-bold mb-0 small"><?php echo e($jam['hu']); ?>%</p>
                                </div>
                                <div class="col-4 border-start border-end">
                                    <p class="text-muted small mb-1">Angin</p>
                                    <p class="fw-bold mb-0 small"><?php echo e($jam['ws']); ?> <span style="font-size: 8px;">km/j</span></p>
                                </div>
                                <div class="col-4">
                                    <p class="text-muted small mb-1">Arah</p>
                                    <p class="fw-bold mb-0 small"><?php echo e($jam['wd']); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="mt-5 p-3 bg-light rounded-3 text-center">
            <p class="small text-muted mb-0">Sumber Data: <strong>BMKG (Badan Meteorologi, Klimatologi, dan Geofisika)</strong></p>
            <p class="x-small text-muted" style="font-size: 10px;">Data diperbarui otomatis dari server pusat BMKG</p>
        </div>
    <?php endif; ?>
</div>

<style>
    .bg-soft-primary { background-color: #f0f7ff; color: #007bff; }
    .card { transition: transform 0.2s; }
    .card:hover { transform: translateY(-5px); }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/stametsentani/resources/views/cuacaprakiraan.blade.php ENDPATH**/ ?>