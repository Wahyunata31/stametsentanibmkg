

<?php $__env->startSection('title', 'Input Performa & Kendala Aloptama'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4 mb-5">
    <div class="card border-0 shadow-sm p-4 mb-4">
        <h2 class="h4 text-primary border-bottom pb-2 mb-3">Update Nilai SLA & OLA oleh Teknisi</h2>
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.aloptama.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <table class="table table-bordered align-middle text-center">
                <thead class="table-dark">
                    <tr>
                        <th class="text-start">Nama Alat</th>
                        <th>SLA (%)</th>
                        <th>OLA (%)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $performa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-start fw-bold"><?php echo e($item->nama_alat); ?></td>
                        <td>
                            <input type="number" step="0.01" min="0" max="100" name="performa[<?php echo e($item->id); ?>][sla]" value="<?php echo e($item->sla); ?>" class="form-control text-center mx-auto" style="max-width: 100px;">
                        </td>
                        <td>
                            <input type="number" step="0.01" min="0" max="100" name="performa[<?php echo e($item->id); ?>][ola]" value="<?php echo e($item->ola); ?>" class="form-control text-center mx-auto" style="max-width: 100px;">
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="text-end">
                <button type="submit" class="btn btn-primary">Simpan Perubahan Performa</button>
            </div>
        </form>
    </div>

    <div class="row">
        <div class="col-md-5">
            <div class="card border-0 shadow-sm p-4 mb-4">
                <h2 class="h4 text-danger border-bottom pb-2 mb-3">Laporkan Kendala Baru</h2>
                <?php if(session('success_kendala')): ?>
                    <div class="alert alert-success"><?php echo e(session('success_kendala')); ?></div>
                <?php endif; ?>

                <form action="<?php echo e(route('admin.aloptama.kendala.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Pilih Alat/Perangkat</label>
                        <select name="kode_alat" class="form-select" required>
                            <option value="">-- Pilih Alat --</option>
                            <?php $__currentLoopData = $performa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->kode_alat); ?>"><?php echo e($item->nama_alat); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Deskripsi Kendala Pemeliharaan</label>
                        <textarea name="deskripsi_kendala" rows="4" class="form-control" placeholder="Tulis rincian kerusakan, kendala listrik, jaringan atau progres perbaikan di sini..." required></textarea>
                    </div>
                    <button type="submit" class="btn btn-danger w-100">Kirim Laporan Kendala</button>
                </form>
            </div>
        </div>

        <div class="col-md-7">
            <div class="card border-0 shadow-sm p-4">
                <h2 class="h4 text-dark border-bottom pb-2 mb-3">Daftar Status Kendala Alat</h2>
                <div class="table-responsive">
                    <table class="table table-striped align-middle border text-center small">
                        <thead class="table-secondary">
                            <tr>
                                <th class="text-start">Alat & Kendala</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $riwayatKendala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kndl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="text-start">
                                    <strong class="text-dark"><?php echo e($kndl->nama_alat); ?></strong>
                                    <div class="text-muted mt-1"><?php echo e($kndl->deskripsi_kendala); ?></div>
                                    <small class="text-black-50 d-block mt-1">Dilaporkan: <?php echo e(date('d-m-Y H:i', strtotime($kndl->created_at))); ?></small>
                                </td>
                                <td>
                                    <span class="badge <?php echo e($kndl->status == 'Dalam Proses' ? 'bg-warning text-dark' : 'bg-success'); ?>">
                                        <?php echo e($kndl->status); ?>

                                    </span>
                                </td>
                                <td>
                                    <?php if($kndl->status == 'Dalam Proses'): ?>
                                        <form action="<?php echo e(route('admin.aloptama.kendala.selesai', $kndl->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-success">Selesai</button>
                                        </form>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="3" class="text-muted py-3">Belum ada laporan kendala alat.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/stametsentani/resources/views/admin/aloptama_input.blade.php ENDPATH**/ ?>