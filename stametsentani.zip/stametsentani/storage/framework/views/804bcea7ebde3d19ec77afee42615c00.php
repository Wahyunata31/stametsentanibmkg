
<?php $__env->startSection('title', 'Daftar Gempa M 5.0+'); ?>

<?php $__env->startSection('page_title', 'Daftar Gempa M 5.0+'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="#" class="text-decoration-none">Gempa Bumi</a></li>
    <li class="breadcrumb-item" aria-current="page">Gempa Bumi M 5.0+</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title', 'Daftar Gempa M 5.0+'); ?>

<?php $__env->startSection('page_description'); ?>
    Informasi gempa bumi M 5.0+ di wilayah Indonesia.
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2 class="mb-4">Daftar 15 Gempabumi M 5.0+</h2>
    <div class="table-responsive shadow-sm border rounded">
        <table class="table table-hover mb-0">
            <thead class="table-dark">
                <tr>
                    <th>No</th><th>Waktu</th><th>Magnitudo</th><th>Kedalaman</th><th>Lokasi</th><th>Potensi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data->gempa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($g->Tanggal); ?> <?php echo e($g->Jam); ?></td> 
                    <td><span class="badge bg-warning text-dark"><?php echo e($g->Magnitude); ?></span></td> 
                    <td><?php echo e($g->Kedalaman); ?></td> 
                    <td><?php echo e($g->Wilayah); ?></td>
                    <td><?php echo e($g->Potensi); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <p class="mt-3 text-muted small">* Sumber: BMKG</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/stametsentani/resources/views/gempa/m5plus.blade.php ENDPATH**/ ?>